﻿// Le portail de présentation francophone de JCE: jce.sarki.ch 
// Traductions et supports francophones par Sarki: www.sarki.ch
tinyMCE.addI18n('fr.hshtmlexpander_dlg',{
desc : 'Insérer/Editer popup HTML',
title : 'Insérer/Editer un popup HTML',
need_objecttype: 'Vous devez spécifier le type de contenu pour le chargement des scripts correspondants..',
is_expander: 'Vous devez utiliser le plugin "Popup Image Highslide" avec lequel ce popup a été créé.'
});