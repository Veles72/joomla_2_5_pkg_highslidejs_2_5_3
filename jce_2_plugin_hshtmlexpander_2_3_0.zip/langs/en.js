// UK lang variables
tinyMCE.addI18n('en.hshtmlexpander',{
desc : 'Insert/modify Highslide HTML expander',
delta_width : 0,
delta_height : 0
});