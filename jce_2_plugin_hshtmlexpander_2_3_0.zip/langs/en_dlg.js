tinyMCE.addI18n('en.hshtmlexpander_dlg',{
desc : 'Inserts/edit html expander',
title : 'Insert/Modify Highslide Html Expander',
need_objecttype: 'Object type must be set to ajax, iframe or flash for unobtrusive markup.',
is_expander: 'This expander was created by the HsExpander plugin. It must be used for updates.'
});