﻿// Le portail de présentation francophone de JCE: jce.sarki.ch 
// Traductions et supports francophones par Sarki: www.sarki.ch
tinyMCE.addI18n('fr.hshtmlexpander',{
desc : 'Insérer/Editer un popup HTML',
delta_width : 0,
delta_height : 0
});