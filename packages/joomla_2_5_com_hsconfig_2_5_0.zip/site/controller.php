<?php
/**
 * Highslide Configuration default controller
 *
 * @license		GNU/GPL
 */

jimport('joomla.application.component.controller');

/**
 * Highslide Configuration Component Controller
 *
 * @package		HsConfig
 */
class HsConfigController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		parent::display();
	}

}
?>
