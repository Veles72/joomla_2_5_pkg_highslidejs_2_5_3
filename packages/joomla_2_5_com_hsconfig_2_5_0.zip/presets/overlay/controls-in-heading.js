/* overlay preset: controls-in-heading */
	,className: 'controls-in-heading'
});