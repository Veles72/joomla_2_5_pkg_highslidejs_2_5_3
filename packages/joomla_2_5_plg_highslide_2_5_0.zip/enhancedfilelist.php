<?php
/**
 * @version		$Id: enhancedfilelist.php 16825 2010-05-05 12:10:37Z louis $
 * @package		Joomla.Framework
 * @subpackage	Form
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// Check to ensure this file is within the rest of the framework
defined('JPATH_BASE') or die();

jimport('joomla.html.html');
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');
jimport('joomla.form.formfield');
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');

/**
 * Supports an HTML select list of file
 *
 * @package		Joomla.Framework
 * @subpackage	Form
 * @since		1.6
 */

class JFormFieldEnhancedFilelist extends JFormFieldList
{
	/**
	* Element name
	*
	* @var		string
	*/
	public	$type = 'EnhancedFilelist';

	function getOptions()
	{
		// Initialize variables.
		$options = array();

		// Initialize some field attributes.
		$filter			= (string) $this->element['filter'];
		$exclude		= (string) $this->element['exclude'];
		$stripExt		= (string) $this->element['stripext'];
		$valueKwd  		= (string) $this->element['valuekwd'];
		$hideNone		= (string) $this->element['hide_none'];
		$hideDefault	= (string) $this->element['hide_default'];

		// Get the path in which to search for file options.
		$path = (string) $this->element['directory'];
		if (!is_dir($path))
		{
			$path = JPATH_ROOT.'/'.$path;
		}

		// Prepend some default options based on field attributes.
		if (!$hideNone)
		{
			$options[] = JHtml::_('select.option', '-1', JText::_('JOPTION_DO_NOT_USE'));
		}
		if (!$hideDefault)
		{
			$options[] = JHtml::_('select.option', '', JText::_('JOPTION_USE_DEFAULT'));
		}

		// Get a list of files in the search path with the given filter.
		$files = JFolder::files($path, $filter);

		if ( is_array($files) )
		{
			foreach ($files as $file)
			{
				if ($exclude)
				{
					if (preg_match( chr( 1 ) . $exclude . chr( 1 ), $file ))
					{
						continue;
					}
				}
				$fullfile = JPath::clean( $path.DS.$file );
				if ($stripExt)
				{
					$file = JFile::stripExt( $file );
				}
				$val = "(".JString::strtoupper($file).")";
				if ($valueKwd)
				{
					$text = JFile::read($fullfile);
					if ($text !== false)
					{
						$expr = "#".$valueKwd.":( *)([^ \n\r]*)"."#i";
						if ( preg_match( $expr, $text, $match ))
						{
							$val = $val." ".$match[2];
						}
					}
				}
				$options[] = JHtml::_('select.option', $file, $val);
			}
		}

		// Merge any additional options in the XML definition.
		$options = array_merge(parent::getOptions(), $options);

		return $options;
	}
}