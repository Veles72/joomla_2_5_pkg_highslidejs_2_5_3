<?php
/**
 * Highslide JS Plugin
 *
 * @license		GNU/GPL
 */

// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die;

jimport( 'joomla.plugin.plugin' );
jimport( 'joomla.filesystem.file');
jimport( 'joomla.utilities.string');
jimport( 'joomla.language.helper');

/**
 * Highslide Content Plugin
 *
 */
class plgContentHighslide extends JPlugin
{

	/**
	 * onContentPrepare
	 *
	 * Method is called by the view
	 *
	 * @param	string	The context of the content being passed to the plugin.
	 * @param	object	The article object.  Note $article->text is also available
	 * @param	object	The article params
	 * @param	int		The 'page' number
	 */
	public function onContentPrepare( $context, &$article, &$params, $page=0 )
	{
		$plugin			= JPluginHelper::getPlugin('content', 'highslide');
		$pluginParams 	= new JRegistry;
		$pluginParams->loadJSON($plugin->params);
		$highslideroot	= JPATH_ROOT.DS.'plugins'.DS.'content'.DS.'highslide'.DS;


		if ( isset($article->id)
		   &&isset($article->text)
		   )
		{
			if ($pluginParams->getValue('includehsconfig') == '0')
			{
				if (! preg_match( "/(class|rel)=\".*highslide/i", $article->text, $match ))
				{
					return;
				}
			}

			$id = $article->id;
			$fname = $highslideroot.'config'.DS.'css'.DS.'highslide-article-' . $article->id . '-styles.css';
			if (!JFile::exists($fname))
			{
				//
				//	no config, see if system plugin is installed
				//
				$splugin = JPluginHelper::getPlugin( 'system', 'highslide');
				if (count($splugin) != 0)
				{
					$sparams = new JRegistry;
					$sparams->loadJSON($splugin->params);

					// check whether plugin is enabled
					if ($sparams->get('enabled', 1) == 1)
					{
						// if include option is always, let the system plugin
						// do it if it is still neccessary after going through
						// all the articles on the page
						if ($pluginParams->getValue('includehsconfig') == '1')
						{
							return true;
						}
					}
				}
				// no config for this article, default to site config
				$id = -1;
			}
		}
		else
		{
			return;
		}

		$this->_checkContent( $pluginParams, $id );
	}

	public static function _checkContent( &$pluginParams, $id )
	{
		jimport('joomla.environment.browser');
		$document 	= JFactory::getDocument();
		$browser	= JBrowser::getInstance();
		$hs_base    = JURI::root(true). '/plugins/content/highslide/';
		$hs_root	= JPATH_ROOT.DS.'plugins'.DS.'content'.DS.'highslide'.DS;
		$lang		= plgContentHighslide::_getLanguage( $pluginParams );
		$HS_JS_TYPE = "";

		$inchighslide = $pluginParams->getValue('includehighslide');
		if ($inchighslide == '0')
		{
			$HS_JS_TYPE = 'highslide-full.js';
		}
		if ($inchighslide == '1')
		{
			$HS_JS_TYPE = 'highslide-full.packed.js';
		}
		if ($inchighslide == '2')
		{
			$HS_JS_TYPE = 'highslide-full.min.js';
		}

		//	see if there is already a confguration loaded for this page
		$hsscript = $hs_base.$HS_JS_TYPE;
		$headdata = $document->getHeadData();
		if ($headdata != null)
		{
			$keys= array_keys( $headdata['scripts']);
			$fname = $hs_base.'config/js/';
			foreach ($keys as $script )
			{
				$script = str_ireplace( $fname, "", $script );
				if ($script == "highslide-sitesettings.js"
				   ||JString::strpos( $script, "highslide-article-") === 0
				   )
				{
					//	already have a config, get out
					return;
				}
			}
		}
		$fnameCss = plgContentHighslide::_createCssUrl( $id );
		$fnameJs = plgContentHighslide::_createJsUrl( $id );

		if ($inchighslide != '3')
		{
			$document->addStylesheet( $hs_base.'highslide.css');
			if ($browser->getBrowser() == "msie" && $browser->getMajor() <= 6)
			{
				$ie6css = $hs_root.'highslide-ie6.css';
				if (JFile::exists($ie6css))
				{
					$styledata = JFile::read($ie6css);
					$newtext = preg_replace( "/src=( )*'( )*([^' ]+)'/i", "src='" . JURI::root(true) . "\\3" . "'", $styledata );
					$document->addStyleDeclaration($newtext);
				}
			}
		}
		$document->addStylesheet( $fnameCss );
		if ($inchighslide != '3')
		{
			$document->addScript( $hs_base.$HS_JS_TYPE );
			$document->addScript( $hs_base.'easing_equations.js');
			if ( $pluginParams->getValue('includeswfobject') != "0")
			{
				$document->addScript( $hs_base.'swfobject.js');
			}
		}
		if (isset($lang))
		{
			$document->addScript( $hs_base.'language/'.$lang.'.js');
		}
		else
		{
			if ($pluginParams->getValue('defaultlang') != -1)
			{
				$document->addScript( $hs_base.'language/'.$pluginParams->getValue('defaultlang').'.js');
			}
		}
		$document->addScript( $fnameJs);
		$document->addScriptDeclaration( "hs.graphicsDir = '".$hs_base."graphics/';");
	}

	/**
	 * Determine if the id given represents the site configuration
	 *
	 * @param mixed $id
	 * @return true if id is for the site configuration, otherwise false
	 */
	protected static function _isSiteConfig( $id )
	{
		return ($id == -1);
	}

	/**
	 * create a CSS stylesheet name based upon the id given
	 *
	 * @param mixed $id
	 * @return full path file name
	 */
	protected static function _createCssUrl( $id )
	{
		$fname = JURI::root(true).'/plugins/content/highslide/config/css/';

		if (plgContentHighslide::_isSiteConfig($id) )
		{
			$fname .=  'highslide-sitestyles.css';
		}
		else
		{
			$fname .= 'highslide-article-' . $id . '-styles.css';
		}
		return $fname;
	}

	/**
	 * create a Javascript file name based upon the id given
	 *
	 * @param mixed $id
	 * @return full path file name
	 */
	protected static function _createJsUrl( $id )
	{
		$fname = JURI::root(true).'/plugins/content/highslide/config/js/';

		if (plgContentHighslide::_isSiteConfig($id) )
		{
			$fname .=  'highslide-sitesettings.js';
		}
		else
		{
			$fname .= 'highslide-article-' . $id . '-settings.js';
		}
		return $fname;
	}

	protected static function _getLanguage( $params )
	{
		if ($params->get('detectlang','1') == '1')
		{
			$dir = dirname( __FILE__ ).DS.'language'.DS;
			if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE']))
			{
				$browserLangs	= explode( ',', $_SERVER['HTTP_ACCEPT_LANGUAGE'] );

				foreach ($browserLangs as $browserLang)
				{
					// slice out the part before ; on first step, the part before - on second, place into array
					$browserLang = substr( $browserLang, 0, strcspn( $browserLang, ';' ) );
					$primary_browserLang = substr( $browserLang, 0, 2 );

					if (JFile::exists( $dir.$browserLang.'.js'))
					{
						return $browserLang;
					}
					if (JFile::exists( $dir.$primary_browserLang.'.js'))
					{
						return $primary_browserLang;
					}
				}
			}
		}
		return;
	}
}
?>