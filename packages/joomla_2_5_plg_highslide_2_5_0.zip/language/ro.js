/*
 * language: Romanian
*/
hs.lang = {
   loadingText :     'Incarca...',
   loadingTitle :    'Apasa pentru a anula',
   focusTitle :      'Apasa pentru a aduce in fata',
   fullExpandTitle : 'Mareste la marimea natura',
   fullExpandText :  'Marimea naturala',
   creditsText :     '<i>Powerd by Highslide JS</i>',
   creditsTitle :    'Mergi la pagina Highslide',
   previousText :    'Inapoi',
   previousTitle :   'Inapoi (sageata din stanga)',
   nextText :        'Inainte',
   nextTitle :       'Inainte (sageata din dreapta)',
   moveTitle :       'Muta',
   moveText :        'Muta',
   closeText :       'Inchide',
   closeTitle :      'Inchide (esc)',
   resizeTitle :     'Redimensioneaza',
   playText :        'Porneste',
   playTitle :       'Porneste prezentarea (bara de spatiu)',
   pauseText :       'Opreste',
   pauseTitle :      'Opreste prezentarea (bara de spatiu)',
   restoreTitle :    'Apasa pentru a inchide imaginea, apasa pentru a muta. Foloseste sagetelele pentru inainte si inapoi.'
};
