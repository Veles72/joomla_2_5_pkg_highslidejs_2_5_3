// UK lang variables
tinyMCE.addI18n('en.hsexpander',{
desc : 'Insert/modify Highslide expander',
delta_width : 0,
delta_height : 0
});