﻿tinyMCE.addI18n('fr.hsexpander_dlg',{
desc : 'Insérer/Editer un Popup',
title : 'Insérer/Editer un Popup Highslide',
is_htmlexpander: 'Vous devez utiliser le plugin "Popup HTML Highslide" avec lequel ce popup a été créé.'
});