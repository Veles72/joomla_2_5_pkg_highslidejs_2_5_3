tinyMCE.addI18n('en.hsexpander_dlg',{
desc : 'Insert/edit expander',
title : 'Insert/modify Highslide Expander',
is_htmlexpander: 'This expander was created by the HsHtmlExpander plugin. It must be used for updates.'
});